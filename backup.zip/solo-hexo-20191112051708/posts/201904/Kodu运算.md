title: Kodu - 运算
date: '2019-04-03 00:46:59'
updated: '2019-04-03 00:46:59'
tags: [Kodu, 儿童编程]
permalink: /articles/2019/04/03/1554223619551.html
---
Kodu的运算只支持2种(加, 减), 应该是因为只为儿童编程的缘故.
但有变量由于设计3种类型, 分别是显示的全局变量(显示在右上角), 不显示的全局变量, 不显示的私有变量(每个对象有一份)

如下以"显示的全局变量"的加减法为例
![image.png](https://img.hacpai.com/file/2019/04/image-5eafa435.png)