title: Python 变量
date: '2019-03-14 22:35:53'
updated: '2019-03-14 22:35:53'
tags: [Python]
permalink: /articles/2019/03/14/1552574153073.html
---
数据类型
------
Python 在内存中存储的数据可以有多种类型。
有五个标准的数据类型：

*   Numbers（数字）
*   String（字符串）
*   List（列表）
*   Tuple（元组）
*   Dictionary（字典）