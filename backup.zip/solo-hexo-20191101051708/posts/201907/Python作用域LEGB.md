title: Python 作用域(LEGB)
date: '2019-07-27 21:58:30'
updated: '2019-07-27 21:58:30'
tags: [Python]
permalink: /articles/2019/07/27/1564235910430.html
---
# LEGB
LEGB就是用来规定命名空间查找顺序的规则, 顺序是 L> E > G > B

1. **L**ocal
函数内的名字空间  
2. **E**nclosing function locals, 
外部嵌套函数的名字空间
3. **G**lobal, 
函数定义所在模块（文件）的名字空间  
4. **B**uiltin, 
内置模块的名字空间