title: Kodu - 创建游戏角色
date: '2019-03-25 00:15:08'
updated: '2019-03-25 00:15:08'
tags: [Kodu, 儿童编程]
permalink: /articles/2019/03/25/1553444108085.html
---
创建我们的第一个游戏角色, 通过WASD控制移动, 空格键发射炮弹.

我们创建第一个游戏, 点击"New world".

![image.png](https://img.hacpai.com/file/2019/03/image-52e07b22.png)

- 点击工具栏中![image.png](https://img.hacpai.com/file/2019/03/image-d9491298.png), 选择菜单中kodu, 添加对象.

![image.png](https://img.hacpai.com/file/2019/03/image-1ae1f6f1.png)

- 对kodu右键, 对kodu进行如下编程
![image.png](https://img.hacpai.com/file/2019/03/image-8c952dbc.png)