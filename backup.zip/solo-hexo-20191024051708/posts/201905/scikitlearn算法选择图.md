title: scikit-learn算法选择图
date: '2019-05-14 23:37:35'
updated: '2019-05-14 23:37:35'
tags: [AI, scikit-learn, 机器学习]
permalink: /articles/2019/05/14/1557848255248.html
---
图片摘抄于scikit-learn官网, 供参考

![image.png](https://img.hacpai.com/file/2019/05/image-9754e582.png)

原图(高清): [https://scikit-learn.org/stable/_static/ml_map.png](https://scikit-learn.org/stable/_static/ml_map.png)