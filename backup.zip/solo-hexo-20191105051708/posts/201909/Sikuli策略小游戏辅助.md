title: Sikuli - 策略小游戏辅助
date: '2019-09-15 13:55:42'
updated: '2019-09-15 13:55:42'
tags: [Sikuli, 作品]
permalink: /articles/2019/09/15/1568526942574.html
---
本人也是一个游戏爱好者, 经常喜欢玩一下策略小游戏, 最近尝试玩了一款"The Tribez"的游戏, 于是花了些时间, 学习了Sikuli软件, 编写了简单的游戏辅助功能

# 游戏界面
![image.png](https://img.hacpai.com/file/2019/09/image-478fdb21.png)

# Skiuli 脚本
设计上, 希望用异常, 由于不熟悉, 只能先catch住.
功能简单, 搜金币, 种植等.
![image.png](https://img.hacpai.com/file/2019/09/image-32d1e08d.png)
![image.png](https://img.hacpai.com/file/2019/09/image-8f6056af.png)