title: 大疆 - ROBOMASTER S1
date: '2019-07-08 23:05:28'
updated: '2019-07-08 23:05:28'
tags: [大疆, 好玩]
permalink: /articles/2019/07/08/1562598328197.html
---
大疆推出其首款教育机器人, 又把我惊艳到了. 不过价格也不便宜, 3499.
具体可查看官方网站 [https://www.dji.com/cn/robomaster-s1](https://www.dji.com/cn/robomaster-s1)

具体有如下几个特点
- **发射器 & 感应机甲**
支持对平台对战
- **麦克纳姆轮**
四驱全向运动系统, 可横向移动, 看着就非常酷
- **FPV**
第一人称视角, 让使用者拥有声临其境的感觉
- **可编程**
支持Scratch & Python语言, 适合初学者开发 

![image.png](https://img.hacpai.com/file/2019/07/image-0e3c8e0a.png)